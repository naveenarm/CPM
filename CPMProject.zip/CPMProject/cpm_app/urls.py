from django.urls import path
from .views import get_activity_form, reset_activities, compute_cpm_view

urlpatterns = [
    path('', get_activity_form, name='add_activity'),
    path('reset/', reset_activities, name='reset_activities'),
    path('compute/', compute_cpm_view, name='compute_cpm'),
]
