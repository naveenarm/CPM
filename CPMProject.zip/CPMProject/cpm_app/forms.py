from django import forms

class ActivityForm(forms.Form):
    activity = forms.CharField(label='Activity Name', max_length=100)
    duration = forms.IntegerField(label='Duration')
    predecessors = forms.CharField(label='Predecessors', required=False, help_text='Comma-separated list of predecessors')
