from django.shortcuts import render, redirect
from django.http import HttpResponse
from .forms import ActivityForm
import networkx as nx
import matplotlib.pyplot as plt
from io import BytesIO
import base64
from collections import deque

def get_activity_form(request):
    if request.method == 'POST':
        form = ActivityForm(request.POST)
        if form.is_valid():
            activity = form.cleaned_data['activity']
            duration = form.cleaned_data['duration']
            predecessors = form.cleaned_data['predecessors'].split(',')
            predecessors = [p.strip() for p in predecessors if p.strip()]
            
            if 'activities' not in request.session:
                request.session['activities'] = {}
            
            activities = request.session['activities']
            activities[activity] = (duration, predecessors)
            request.session['activities'] = activities

            return redirect('add_activity')
    else:
        form = ActivityForm()

    activities = request.session.get('activities', {})
    return render(request, 'add_activity.html', {'form': form, 'activities': activities})

def reset_activities(request):
    request.session['activities'] = {}
    return redirect('add_activity')

def compute_cpm_view(request):
    activities = request.session.get('activities', {})
    if not activities:
        return HttpResponse("No activities entered")

    G = create_graph(activities)
    add_start_finish_nodes(G)
    early_start, early_finish, latest_start, latest_finish, float_values, critical_path, start_nodes, end_nodes = compute_cpm(G)
    graph_image = draw_graph(G, early_start, early_finish, latest_start, latest_finish, float_values, critical_path, start_nodes, end_nodes)

    context = {
        'early_start': early_start,
        'early_finish': early_finish,
        'latest_start': latest_start,
        'latest_finish': latest_finish,
        'float_values': float_values,
        'critical_path': critical_path,
        'graph_image': graph_image
    }

    return render(request, 'cpm_result.html', context)

def index(request):
    if request.method == 'POST':
        activities = {}
        for key in request.POST:
            if key.startswith('activity'):
                index = key.split('_')[1]
                activity = request.POST[key]
                duration = int(request.POST[f'duration_{index}'])
                predecessors = request.POST[f'predecessors_{index}'].split(',')
                predecessors = [p.strip() for p in predecessors if p.strip()]
                activities[activity] = (duration, predecessors)

        G = create_graph(activities)
        add_start_finish_nodes(G)
        early_start, early_finish, latest_start, latest_finish, float_values, critical_path, start_nodes, end_nodes = compute_cpm(G)
        
        critical_path_str = ' -> '.join(critical_path)
        return HttpResponse(f"Critical Path: {critical_path_str}")

    return render(request, 'index.html')

def create_graph(activities):
    G = nx.DiGraph()
    for node, (duration, predecessors) in activities.items():
        G.add_node(node, duration=duration)
        for pred in predecessors:
            G.add_edge(pred, node)
    return G

def add_start_finish_nodes(G):
    start_nodes = [node for node in G.nodes if len(list(G.predecessors(node))) == 0]
    end_nodes = [node for node in G.nodes if len(list(G.successors(node))) == 0]
    
    if start_nodes and 'Start' not in G.nodes:
        start_node = 'Start'
        G.add_node(start_node)
        for node in start_nodes:
            G.add_edge(start_node, node)
    
    if end_nodes and 'Finish' not in G.nodes:
        end_node = 'Finish'
        G.add_node(end_node)
        for node in end_nodes:
            G.add_edge(node, end_node)

def compute_cpm(G):
    early_start = {}
    early_finish = {}
    
    for node in nx.topological_sort(G):
        duration = G.nodes[node].get('duration', 0)
        if len(list(G.predecessors(node))) == 0:
            early_start[node] = 0
        else:
            early_start[node] = max(early_finish[pred] for pred in G.predecessors(node))
        early_finish[node] = early_start[node] + duration
    
    latest_start = {}
    latest_finish = {}
    project_duration = max(early_finish.values())
    
    for node in reversed(list(nx.topological_sort(G))):
        if len(list(G.successors(node))) == 0:
            latest_finish[node] = project_duration
        else:
            latest_finish[node] = min(latest_start[succ] for succ in G.successors(node))
        latest_start[node] = latest_finish[node] - G.nodes[node].get('duration', 0)
    
    float_values = {node: latest_start[node] - early_start[node] for node in G.nodes}
    critical_path = ['Start'] + [node for node in G.nodes if float_values[node] == 0 and node not in ['Start', 'Finish']] + ['Finish']
    
    return early_start, early_finish, latest_start, latest_finish, float_values, critical_path, None, None

def draw_graph(G, early_start, early_finish, latest_start, latest_finish, float_values, critical_path, start_nodes, end_nodes):
    pos = {}
    queue = deque()
    level = 0
    nodes_by_level = {}

    for node in nx.topological_sort(G):
        pos[node] = (level, len(nodes_by_level.get(level, [])))
        nodes_by_level.setdefault(level, []).append(node)
        for succ in G.successors(node):
            if succ not in pos:
                queue.append((succ, level + 1))
        if not queue:
            level += 1
        while queue:
            node, lvl = queue.popleft()
            pos[node] = (lvl, len(nodes_by_level.get(lvl, [])))
            nodes_by_level.setdefault(lvl, []).append(node)
            for succ in G.successors(node):
                if succ not in pos:
                    queue.append((succ, lvl + 1))

    node_colors = ['lightgreen' if node == 'Start' else 'lightcoral' if node == 'Finish' else 'lightblue' for node in G.nodes]
    node_sizes = [4000 if node == 'Start' or node == 'Finish' else 3000 for node in G.nodes]
    edge_colors = ['red' if (u in critical_path and v in critical_path) else 'black' for u, v in G.edges]

    labels = {
        node: (f"{node}\nES={early_start[node]}\nEF={early_finish[node]}\nLS={latest_start[node]}\nLF={latest_finish[node]}\nD={G.nodes[node].get('duration', 0)}\nF={float_values[node]}")
        for node in G.nodes
    }
    labels.update({'Start': 'Start'})
    labels.update({'Finish': 'Finish'})

    plt.figure(figsize=(16, 10))
    nx.draw(G, pos, with_labels=False, node_color=node_colors, node_size=node_sizes, font_size=10, font_weight='bold', arrows=True, edge_color=edge_colors)
    nx.draw_networkx_labels(G, pos, labels=labels, font_size=8, font_weight='bold')

    critical_edges = [(u, v) for u, v in G.edges if u in critical_path and v in critical_path]
    nx.draw_networkx_edges(G, pos, edgelist=critical_edges, edge_color='red', width=2, style='dashed')

    plt.title('CPM Network Diagram with Critical Path')
    
    buf = BytesIO()
    plt.savefig(buf, format='png')
    plt.close()
    image_base64 = base64.b64encode(buf.getvalue()).decode('utf-8')
    return image_base64
